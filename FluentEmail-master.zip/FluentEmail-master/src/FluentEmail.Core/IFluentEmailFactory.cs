﻿namespace FluentEmail.Core
{
    public interface IFluentEmailFactory
    {
        IFluentEmail Create();
    }
}