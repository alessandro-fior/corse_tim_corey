﻿namespace FluentEmail.Core.Models
{
    public enum Priority
    {
        High = 1,
        Normal = 2,
        Low = 3
    }
}
