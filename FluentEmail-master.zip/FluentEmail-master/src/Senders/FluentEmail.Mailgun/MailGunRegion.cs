namespace FluentEmail.Mailgun
{
    public enum MailGunRegion
    {
        USA,
        EU
    }
}