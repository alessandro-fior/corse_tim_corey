# Contributing to SharpZipLib

Thanks for helping to improve SharpZipLib.

In order for your changes to be accepted you can either sign the [Joint Copyright Assignment](http://www.icsharpcode.net/TechNotes/JointCopyrightAssignment.pdf) or add the following statement to your pull request:

_I certify that I own, and have sufficient rights to contribute, all source code and related material intended to be compiled or integrated with the source code for the SharpZipLib open source product (the "Contribution"). My Contribution is licensed under the MIT License._

Unless we have a Joint Copyright Agreement on file or this statement is in your pull request, we cannot accept it.

More information is available on [joining the team](https://github.com/icsharpcode/SharpDevelop/wiki/Joining-the-Team).
