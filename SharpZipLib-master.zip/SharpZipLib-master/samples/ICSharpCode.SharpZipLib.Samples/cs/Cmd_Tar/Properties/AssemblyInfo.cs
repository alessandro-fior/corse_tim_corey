using System.Reflection;

// Information about this assembly is defined by the following
// attributes.
//
// change them to the information which is associated with the assembly
// you compile.

[assembly: AssemblyTitle("Tar Sharp Sample")]
[assembly: AssemblyDescription("A simple tar application")]
[assembly: AssemblyCulture("")]
