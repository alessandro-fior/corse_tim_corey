Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ZipFileTest")>
<Assembly: AssemblyDescription("SharpZipLib Sample Project")>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("64583B4A-0212-43A2-AA36-F0E292EDC573")>
