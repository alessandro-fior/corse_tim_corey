using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Hangfire")]
[assembly: AssemblyCompany("Sergey Odinokov")]
[assembly: AssemblyCopyright("Copyright © 2013-2016 Sergey Odinokov")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

// Don't edit manually! Use `build.bat version` command instead!
[assembly: AssemblyVersion("1.7.24")]
