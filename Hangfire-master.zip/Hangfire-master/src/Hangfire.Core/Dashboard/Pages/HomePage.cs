﻿using System.Collections.Generic;

namespace Hangfire.Dashboard.Pages
{
    partial class HomePage
    {
        public static readonly List<DashboardMetric> Metrics = new List<DashboardMetric>(); 
    }
}
