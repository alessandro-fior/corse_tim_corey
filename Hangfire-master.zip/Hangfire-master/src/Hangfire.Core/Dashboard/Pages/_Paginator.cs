﻿namespace Hangfire.Dashboard.Pages
{
    partial class Paginator
    {
        private readonly Pager _pager;

        public Paginator(Pager pager)
        {
            _pager = pager;
        }
    }
}
