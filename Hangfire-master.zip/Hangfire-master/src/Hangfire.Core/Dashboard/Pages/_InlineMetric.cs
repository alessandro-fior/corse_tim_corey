﻿namespace Hangfire.Dashboard.Pages
{
    partial class InlineMetric
    {
        public InlineMetric(DashboardMetric dashboardMetric)
        {
            DashboardMetric = dashboardMetric;
        }

        public DashboardMetric DashboardMetric { get; }
    }
}
