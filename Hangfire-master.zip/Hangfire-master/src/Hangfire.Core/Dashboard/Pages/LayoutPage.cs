﻿namespace Hangfire.Dashboard.Pages
{
    partial class LayoutPage
    {
        public LayoutPage(string title)
        {
            Title = title;
        }

        public string Title { get; }
    }
}
