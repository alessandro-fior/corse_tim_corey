﻿namespace Hangfire.Dashboard.Pages
{
    partial class PerPageSelector
    {
        private readonly Pager _pager;

        public PerPageSelector(Pager pager)
        {
            _pager = pager;
        }
    }
}
