﻿namespace Hangfire.SqlServer
{
    internal class Constants
    {
        public static readonly string DefaultSchema = "HangFire";
    }
}
