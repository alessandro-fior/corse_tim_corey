﻿using System.Reflection;

[assembly: AssemblyTitle("Hangfire.AspNetCore")]
[assembly: AssemblyDescription("ASP.NET Core support for Hangfire")]
