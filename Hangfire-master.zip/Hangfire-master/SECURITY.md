# Reporting security issues 

In order to give the community time to respond and upgrade we strongly urge you report all security issues privately. Please email us at [support@hangfire.io](support@hangfire.io) with details and we will respond ASAP. Security issues always take precedence over bug fixes and feature work. We can and do mark releases as "urgent" if they contain serious security fixes. 
