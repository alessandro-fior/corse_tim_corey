﻿using Xunit;

[assembly: CollectionBehavior(MaxParallelThreads = 1)]
