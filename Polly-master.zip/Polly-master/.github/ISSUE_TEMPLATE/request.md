---
name: Request
about: Suggest a feature request or improvement

---

**Is your feature request related to a specific problem? Or an existing feature? Please describe.**

<br/><br/>

**Describe your proposed or preferred solution**:

<br/><br/>

**Describe any alternative options you've considered**:

<br/><br/>

**Any additional info?**
