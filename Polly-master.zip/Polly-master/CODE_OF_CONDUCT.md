Polly is part of the [.NET Foundation](https://dotnetfoundation.org/), and we ask our contributors to abide by their [Code of Conduct](https://www.dotnetfoundation.org/code-of-conduct).
