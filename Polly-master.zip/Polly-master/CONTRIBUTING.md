Please see our Instructions for Contributing in the [ReadMe](https://github.com/App-vNext/Polly#instructions-for-contributing) and [wiki](https://github.com/App-vNext/Polly/wiki/Git-Workflow).

Please be sure to branch from the head of the latest vX.Y.Z dev branch (rather than master) when developing contributions.  
